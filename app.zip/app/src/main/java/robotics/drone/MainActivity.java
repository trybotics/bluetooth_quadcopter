package robotics.drone;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import java.util.ArrayList;
import android.os.Handler;
import android.os.Message;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.speech.RecognizerIntent;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity  implements SensorEventListener{

//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//    }


    private TextView tv,tvb;
    private BluetoothAdapter mBluetoothAdapter = null;
    private SeekBar sb;
    private Switch c,a;
    private SensorManager senSensorManager;
    private Sensor senAccelerometer;
    private String[] logArray = null;
    private String[] logArray1 = null;
    boolean acc=false;
    private BtInterface bt = null;
    protected static final int RESULT_SPEECH = 2;
    protected static final int REQUEST_ENABLE_BT = 1;
    static final String TAG = "Arduino";
    public static boolean bluetooth_connection = false;
    Button bf,br,bl,bb,byc,byac;
    char z=' ';

    //first, inflate all layout objects, and set click listeners
    //This handler listens to messages from the bluetooth interface and adds them to the log
    final Handler handler = new Handler() {
        public void handleMessage(Message msg) {
            String data = msg.getData().getString("receivedData");
            addToLog1(data);
        }
    };

    //this handler is dedicated to the status of the bluetooth connection
    final Handler handlerStatus = new Handler() {
        public void handleMessage(Message msg) {
            int status = msg.arg1;
            if(status == BtInterface.CONNECTED) {
                addToLog("Connected");
                bluetooth_connection=true;
            } else if(status == BtInterface.DISCONNECTED) {
                addToLog("Disconnected");
            }
        }
    };

    //handles the log view modification
    //only the most recent messages are shown
    private void addToLog(String message)
    {
        for (int i = 1; i < logArray.length; i++)
            logArray[i-1] = logArray[i];
        logArray[logArray.length - 1] = message;
        tv.setText("");
        for (int i = (logArray.length-1); i >= 0; i--)
        {
            if (logArray[i] != null)
                tv.append(logArray[i] + "\n");
        }
    }
    private void addToLog1(String message)
    {
        for (int i = 1; i < logArray1.length; i++)
            logArray1[i-1] = logArray1[i];
        logArray1[logArray1.length - 1] = message;
        tvb.setText("");
        for (int i = (logArray1.length-1); i >= 0; i--)
        {
            if (logArray1[i] != null)
                tvb.append(logArray1[i] + "\n");
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //To display only the last 3 messages
        logArray = new String[8];
        logArray1 = new String[8];
        bf=(Button)findViewById(R.id.f);
        bf.setOnTouchListener(new OnTouchListener() {

            @Override
            public boolean onTouch(View arg0, MotionEvent arg1) {
                if(arg1.getAction()==MotionEvent.ACTION_DOWN)
                {
                    addToLog("Move Forward");
                    bt.sendData("F");
                }
                else if(arg1.getAction()==MotionEvent.ACTION_UP)
                {
                    bt.sendData("X");
                    addToLog("No Change");
                }
                return false;
            }
        });
        bb=(Button)findViewById(R.id.back_arrow);
        bb.setOnTouchListener(new OnTouchListener() {

            @Override
            public boolean onTouch(View arg0, MotionEvent arg1) {
                if(arg1.getAction()==MotionEvent.ACTION_DOWN)
                {
                    addToLog("Move Backward");
                    bt.sendData("B");
                }
                else if(arg1.getAction()==MotionEvent.ACTION_UP)
                {
                    bt.sendData("X");
                    addToLog("No Change");
                }
                return false;
            }
        });
        br=(Button)findViewById(R.id.r);
        br.setOnTouchListener(new OnTouchListener() {

            @Override
            public boolean onTouch(View arg0, MotionEvent arg1) {
                if(arg1.getAction()==MotionEvent.ACTION_DOWN)
                {
                    addToLog("Move Right");
                    bt.sendData("R");
                }
                else if(arg1.getAction()==MotionEvent.ACTION_UP)
                {
                    bt.sendData("X");
                    addToLog("No Change");
                }
                return false;
            }
        });
        bl=(Button)findViewById(R.id.l);
        bl.setOnTouchListener(new OnTouchListener() {

            @Override
            public boolean onTouch(View arg0, MotionEvent arg1) {
                if(arg1.getAction()==MotionEvent.ACTION_DOWN)
                {
                    addToLog("Move Left");
                    bt.sendData("L");
                }
                else if(arg1.getAction()==MotionEvent.ACTION_UP)
                {
                    bt.sendData("X");
                    addToLog("No Change");
                }
                return false;
            }
        });
        byc=(Button)findViewById(R.id.yac);
        byc.setOnTouchListener(new OnTouchListener() {

            @Override
            public boolean onTouch(View arg0, MotionEvent arg1) {
                if(arg1.getAction()==MotionEvent.ACTION_DOWN)
                {
                    addToLog("Rotate Clockwise");
                    bt.sendData("I");
                }
                else if(arg1.getAction()==MotionEvent.ACTION_UP)
                {
                    bt.sendData("X");
                    addToLog("No Change");
                }
                return false;
            }
        });
        byac=(Button)findViewById(R.id.yc);
        byac.setOnTouchListener(new OnTouchListener() {

            @Override
            public boolean onTouch(View arg0, MotionEvent arg1) {
                if(arg1.getAction()==MotionEvent.ACTION_DOWN)
                {
                    addToLog("Rotate Anti-Clockwise");
                    bt.sendData("J");
                }
                else if(arg1.getAction()==MotionEvent.ACTION_UP)
                {
                    bt.sendData("X");
                    addToLog("No Change");
                }
                return false;
            }
        });
        tv = (TextView)findViewById(R.id.tv);
        tvb = (TextView)findViewById(R.id.tvb);

        sb=(SeekBar)findViewById(R.id.sb);
        senSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        senAccelerometer = senSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        sb.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            @Override
            public void onStopTrackingTouch(SeekBar arg0) {}
            @Override
            public void onStartTrackingTouch(SeekBar arg0) {}
            @Override
            public void onProgressChanged(SeekBar arg0, int arg1, boolean arg2) {
                arg1 = (int)(arg1/1.5625);
                char c=(char)arg1;
                bt.sendData(""+c);
                addToLog("Speed = "+arg1);

            }
        });

        c=(Switch)findViewById(R.id.c);
        c.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton arg0, boolean acc) {
                if(acc==true)
                {
                    addToLog("Trying to connect");
                    bt.connect();
                }
                else
                {
                    addToLog("Closing connection");
                    stop();
                    bt.close();
                    finish();
                }

            }
        });

        a=(Switch)findViewById(R.id.a);
        a.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
                if(arg1==true)
                {
                    Accelerometer_on();
                }
                else
                {
                    Accelerometer_off();
                }

            }
        });



        //first of all, we check if there is bluetooth on the phone
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (mBluetoothAdapter == null) {
            // Device does not support Bluetooth
            Log.v(TAG, "Device does not support Bluetooth");
        }
        else{
            //Device supports BT
            if (!mBluetoothAdapter.isEnabled()){
                //if Bluetooth not activated, then request it
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            }
            else{
                //BT activated, then initiate the BtInterface object to handle all BT communication
                bt = new BtInterface(handlerStatus, handler);
            }
        }
    }

    //called only if the BT is not already activated, in order to activate it
    protected void onActivityResult(int requestCode, int resultCode, Intent moreData){

        switch (requestCode) {
            case REQUEST_ENABLE_BT:
                if (requestCode == REQUEST_ENABLE_BT){
                    if (resultCode == Activity.RESULT_OK){
                        //BT activated, then initiate the BtInterface object to handle all BT communication
                        bt = new BtInterface(handlerStatus, handler);
                    }
                    else if (resultCode == Activity.RESULT_CANCELED)
                        Log.v(TAG, "BT not activated");
                    else
                        Log.v(TAG, "result code not known");
                }
                else{
                    Log.v(TAG, "request code not known");
                }
                break;
            case RESULT_SPEECH:
                if (resultCode == RESULT_OK && null != moreData)
                {
                    ArrayList<String> text = moreData.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    tv.setText(text.get(0));
                    voice_command();
                }
                break;
        }


    }

    protected void Accelerometer_off(){

        senSensorManager.unregisterListener(this);
    }
    protected void Accelerometer_on() {
        senSensorManager.registerListener(this, senAccelerometer , SensorManager.SENSOR_DELAY_GAME);
    }




//
//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        // Inflate the menu; this adds items to the action bar if it is present.
//        getMenuInflater().inflate(R.menu.main, menu);
//        menu.add(0,1, 0, "Start");
//        menu.add(0,2, 0, "Sensor Calibration");
//        menu.add(0,3, 0, "About this Application");
//        menu.add(0,4, 0, "Close the Application");
//
//        return true;
//    }
//    public boolean onOptionsItemSelected(MenuItem item) {
//        switch (item.getItemId()) {
//            case 4:
//                bt.close();
//                finish();
//                return true;
//            case 3:
//                Intent intent=new Intent(this,About.class);
//                startActivity(intent);
//                return true;
//            case 2:
//                addToLog("Sensor is Calibrating \n Please wait...");
//                bt.sendData("C");
//                return true;
//            case 1:
//                addToLog("Start");
//                bt.sendData("A");
//                return true;
//        }
//        return true;
//    }



    public void s(View v)
    {
        addToLog("Stop");
        bt.sendData("S");
    }
    public void stop()
    {
        addToLog("Stop");
        bt.sendData("S");
    }
    public void calli(View v)
    {
        addToLog("Sensor is Calibrating \n Please wait...");
        bt.sendData("C");
    }


    @Override
    public void onAccuracyChanged(Sensor arg0, int arg1) {}

    @Override
    public void onSensorChanged(SensorEvent arg0) {
        Sensor mySensor = arg0.sensor;

        if (mySensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            float x = arg0.values[0];
            float y = arg0.values[1];
            // float z = arg0.values[2];
            // addToLog("X = "+x);
            // bt.sendData("X = "+x);
            // addToLog("Y = "+y);
            // bt.sendData("Y = "+y);
            // addToLog("Z = "+z);
            //bt.sendData("Z = "+z);
            if(y<-3)
            {
                if(z!='F')
                {
                    bt.sendData("F");
                    addToLog("Move Forward");
                    z='F';
                }
            }
            else if(y>3)
            {
                if(z!='B')
                {
                    bt.sendData("B");
                    addToLog("Move Backward");
                    z='B';
                }
            }
             if(x<-3)
            {
                if(z!='R')
                {
                    bt.sendData("R");
                    addToLog("Move Right");
                    z='R';
                }
            }
            else if(x>3)
            {
                if(z!='L')
                {
                    bt.sendData("L");
                    addToLog("Move Left");
                    z='L';
                }
            }
            if(x>=-3&&x<=3&&y>=-3&&y<=3)
            {
                if(z!='X')
                {
                    bt.sendData("X");
                    addToLog("No Change");
                    z='X';
                }
            }
        }
    }

    public void vs(View v)
    {
        Intent intentvs = new Intent(
                RecognizerIntent.ACTION_RECOGNIZE_SPEECH);

        intentvs.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, "en-US");

        try {
            startActivityForResult(intentvs, RESULT_SPEECH);
            tv.setText("");
        } catch (ActivityNotFoundException a) {
            Toast t = Toast.makeText(getApplicationContext(),
                    "Ops! Your device doesn't support Speech to Text",
                    Toast.LENGTH_SHORT);
            t.show();
        }
    }

    public void voice_command()
    {
        int l,x=0;
        //String w[]=new String[100];
        String s,s1="",sn="";
        char c;
        s=tv.getText().toString();
        s+=" ";
        l=s.length();
        for(int i=0;i<l;i++)
        {
            c=s.charAt(i);
            if(c!=' ')
            {
                if(c=='0'||c=='1'||c=='2'||c=='3'||c=='4'||c=='5'||c=='6'||c=='7'||c=='8'||c=='9')
                    sn+=c;
                else
                    s1+=c;
            }
            else
            {
                if(s1.equalsIgnoreCase("Forward")||s1.equalsIgnoreCase("Front"))
                {
                    bt.sendData("F");
                    addToLog("Move Forward");
                }
                else if(s1.equalsIgnoreCase("Backward")||s1.equalsIgnoreCase("Back"))
                {
                    bt.sendData("B");
                    addToLog("Move Backward");
                }
                else if(s1.equalsIgnoreCase("Right"))
                {
                    bt.sendData("R");
                    addToLog("Move Right");
                }
                else if(s1.equalsIgnoreCase("Left"))
                {
                    bt.sendData("L");
                    addToLog("Move Left");
                }
                else if(s1.equalsIgnoreCase("Start"))
                {
                    bt.sendData("A");
                    addToLog("Stop");
                }
                else if(s1.equalsIgnoreCase("Stop"))
                {
                    bt.sendData("S");
                    addToLog("Stop");
                }
                else if(s1.equalsIgnoreCase("Up"))
                {
                    bt.sendData("U");
                    addToLog("Move Up");
                }
                else if(s1.equalsIgnoreCase("Down"))
                {
                    bt.sendData("D");
                    addToLog("Move Down");
                }
                else if(s1.equalsIgnoreCase("Clockwise"))
                {
                    bt.sendData("I");
                    addToLog("Move Clockwise");
                }
                else if(s1.equalsIgnoreCase("Anticlockwise"))
                {
                    bt.sendData("J");
                    addToLog("Move Anti-Clockwise");
                }
                else if(sn!="")
                {
                    x=Integer.parseInt(sn);
                    if(x>9)
                        x=x%10;
                    addToLog("Delay = "+x);
                    try {
                        Thread.sleep(x*1000);
                    } catch (InterruptedException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                    bt.sendData("X");
                    addToLog("No Change");
                }
                s1="";
                sn="";
            }
        }

    }





}
